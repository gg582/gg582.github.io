// Utah Teapot software renderer
// Compare three surface-evaluation strategies:
//   1. Classic Bernstein basis evaluation (triangle rasterization)
//   2. Horner's method on the power-basis polynomial (triangle rasterization)
//   3. Batch 4D evaluation: lift positions and tangents into homogeneous 4D
//      vectors, evaluate them together with AVX, and render all points and
//      their tangent directions in one shot.  This is the GPU-friendly path.
//
// Interactive X11 mode (default): software-renders a clean low-poly teapot
// with a three-pass pipeline:
//   Pass 1: raw face/vertex normals of the clean geometry
//   Pass 2: bilateral filter on the normal field (spatial Gaussian x range
//           weight from dot(N_center, N_neighbor)), preserving sharp features
//   Pass 3: per-pixel Blinn-Phong (ambient + diffuse + specular)
// Everything is drawn with XPutImage -- no OpenGL, no GPU.

#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <fstream>
#include <immintrin.h>
#include <iostream>
#include <limits>
#include <map>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

#ifdef _OPENMP
#include <omp.h>
#endif

#ifdef HAS_X11
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>
#endif

// ---------- Basic 3D vector (double precision for rendering) ----------
struct Vec3 {
    double x, y, z;
    Vec3() : x(0), y(0), z(0) {}
    Vec3(double x_, double y_, double z_) : x(x_), y(y_), z(z_) {}

    Vec3 operator+(const Vec3& o) const { return Vec3(x + o.x, y + o.y, z + o.z); }
    Vec3 operator-(const Vec3& o) const { return Vec3(x - o.x, y - o.y, z - o.z); }
    Vec3 operator*(double s) const { return Vec3(x * s, y * s, z * s); }
    Vec3 operator/(double s) const { return Vec3(x / s, y / s, z / s); }
    Vec3& operator+=(const Vec3& o) { x += o.x; y += o.y; z += o.z; return *this; }
};

inline Vec3 operator*(double s, const Vec3& v) { return v * s; }

inline double dot(const Vec3& a, const Vec3& b) {
    return a.x * b.x + a.y * b.y + a.z * b.z;
}
inline Vec3 cross(const Vec3& a, const Vec3& b) {
    return Vec3(
        a.y * b.z - a.z * b.y,
        a.z * b.x - a.x * b.z,
        a.x * b.y - a.y * b.x
    );
}
inline double length(const Vec3& a) { return std::sqrt(dot(a, a)); }
inline Vec3 normalize(const Vec3& a) {
    double len = length(a);
    if (len == 0.0) return Vec3(0, 0, 0);
    return a / len;
}

// ---------- 4D homogeneous vector (float precision for fast batched math) ----------
struct Vec4 {
    float x, y, z, w;
    Vec4() : x(0), y(0), z(0), w(0) {}
    Vec4(float x_, float y_, float z_, float w_) : x(x_), y(y_), z(z_), w(w_) {}
    explicit Vec4(const Vec3& v, float w_ = 0.0f) : x(static_cast<float>(v.x)), y(static_cast<float>(v.y)), z(static_cast<float>(v.z)), w(w_) {}

    Vec4 operator+(const Vec4& o) const { return Vec4(x + o.x, y + o.y, z + o.z, w + o.w); }
    Vec4 operator-(const Vec4& o) const { return Vec4(x - o.x, y - o.y, z - o.z, w - o.w); }
    Vec4 operator*(float s) const { return Vec4(x * s, y * s, z * s, w * s); }
    Vec4& operator+=(const Vec4& o) { x += o.x; y += o.y; z += o.z; w += o.w; return *this; }
};

inline Vec4 operator*(float s, const Vec4& v) { return v * s; }

// ---------- Patch: 16 control points + power basis coefficients ----------
struct Patch {
    // Control points in row-major order; u varies inside a row
    // (cp[j*4 + i] corresponds to u=i, v=j)
    Vec3 cp[16];

    // P(u,v) = sum_{k=0..3} sum_{l=0..3} coeff[k][l] * u^k * v^l
    Vec3 coeff[4][4];

    // Cubic Bernstein -> power basis
    // B0(t) =  1 - 3t + 3t^2 - t^3
    // B1(t) =  0 + 3t - 6t^2 + 3t^3
    // B2(t) =  0 + 0  + 3t^2 - 3t^3
    // B3(t) =  0 + 0  + 0     + t^3
    static const double B[4][4];

    void buildCoefficients() {
        for (int k = 0; k < 4; ++k)
            for (int l = 0; l < 4; ++l)
                coeff[k][l] = Vec3();

        for (int i = 0; i < 4; ++i) {
            for (int j = 0; j < 4; ++j) {
                const Vec3& p = cp[j * 4 + i];
                for (int k = 0; k < 4; ++k) {
                    double bik = B[i][k];
                    if (bik == 0.0) continue;
                    for (int l = 0; l < 4; ++l) {
                        double bjl = B[j][l];
                        if (bjl == 0.0) continue;
                        coeff[k][l] += p * (bik * bjl);
                    }
                }
            }
        }
    }

    // Classic Bernstein-based evaluation (baseline for comparison)
    Vec3 evalBernstein(double u, double v) const {
        double t = u;
        double s = v;
        double t2 = t * t;
        double t3 = t2 * t;
        double omt = 1.0 - t;
        double omt2 = omt * omt;
        double omt3 = omt2 * omt;
        double bu[4] = { omt3, 3.0 * t * omt2, 3.0 * t2 * omt, t3 };

        double s2 = s * s;
        double s3 = s2 * s;
        double oms = 1.0 - s;
        double oms2 = oms * oms;
        double oms3 = oms2 * oms;
        double bv[4] = { oms3, 3.0 * s * oms2, 3.0 * s2 * oms, s3 };

        Vec3 p;
        for (int i = 0; i < 4; ++i) {
            for (int j = 0; j < 4; ++j) {
                p += cp[j * 4 + i] * (bu[i] * bv[j]);
            }
        }
        return p;
    }

    // Evaluate the bicubic polynomial with Horner's method
    // P(u,v) = Q0(v) + u*(Q1(v) + u*(Q2(v) + u*Q3(v)))
    // Qk(v)  = coeff[k][0] + v*(coeff[k][1] + v*(coeff[k][2] + v*coeff[k][3]))
    Vec3 evalHorner(double u, double v) const {
        Vec3 q[4];
        for (int k = 0; k < 4; ++k) {
            q[k] = coeff[k][0] + v * (coeff[k][1] + v * (coeff[k][2] + v * coeff[k][3]));
        }
        return q[0] + u * (q[1] + u * (q[2] + u * q[3]));
    }
};

const double Patch::B[4][4] = {
    { 1.0, -3.0,  3.0, -1.0 },
    { 0.0,  3.0, -6.0,  3.0 },
    { 0.0,  0.0,  3.0, -3.0 },
    { 0.0,  0.0,  0.0,  1.0 }
};

// ---------- AVX2/FMA batched 4D patch: 8 samples at once ----------
//
// This is the GPU-like compute kernel: 8 (u,v) parameter pairs are evaluated
// in parallel using 8-wide float AVX registers.  The coefficients are broadcast
// once per patch, then the same Horner arithmetic runs on all lanes at the
// same time, producing positions and both parametric tangents together.
struct PatchAVX {
    __m256 cx[4][4], cy[4][4], cz[4][4];

    void build(const Patch& p) {
        for (int k = 0; k < 4; ++k) {
            for (int l = 0; l < 4; ++l) {
                cx[k][l] = _mm256_set1_ps(static_cast<float>(p.coeff[k][l].x));
                cy[k][l] = _mm256_set1_ps(static_cast<float>(p.coeff[k][l].y));
                cz[k][l] = _mm256_set1_ps(static_cast<float>(p.coeff[k][l].z));
            }
        }
    }

    // Evaluate 8 samples in parallel.  The caller guarantees that the pointers
    // point to at least 8 consecutive valid floats.
    void eval8(const float* u, const float* v,
               float* px, float* py, float* pz,
               float* dux, float* duy, float* duz,
               float* dvx, float* dvy, float* dvz) const {
        const __m256 uu = _mm256_loadu_ps(u);
        const __m256 vv = _mm256_loadu_ps(v);

        // v-Horner for q_k(v) and q_k'(v) for each coordinate
        __m256 qx[4], qy[4], qz[4];
        __m256 dqx[4], dqy[4], dqz[4];

        for (int k = 0; k < 4; ++k) {
            // q_k(v) = c0 + v*(c1 + v*(c2 + v*c3))
            qx[k] = _mm256_fmadd_ps(vv, cx[k][3], cx[k][2]);
            qx[k] = _mm256_fmadd_ps(vv, qx[k], cx[k][1]);
            qx[k] = _mm256_fmadd_ps(vv, qx[k], cx[k][0]);

            qy[k] = _mm256_fmadd_ps(vv, cy[k][3], cy[k][2]);
            qy[k] = _mm256_fmadd_ps(vv, qy[k], cy[k][1]);
            qy[k] = _mm256_fmadd_ps(vv, qy[k], cy[k][0]);

            qz[k] = _mm256_fmadd_ps(vv, cz[k][3], cz[k][2]);
            qz[k] = _mm256_fmadd_ps(vv, qz[k], cz[k][1]);
            qz[k] = _mm256_fmadd_ps(vv, qz[k], cz[k][0]);

            // q_k'(v) = c1 + v*(2*c2 + 3*v*c3)
            const __m256 two = _mm256_set1_ps(2.0f);
            const __m256 three = _mm256_set1_ps(3.0f);

            __m256 tx = _mm256_fmadd_ps(three, _mm256_mul_ps(vv, cx[k][3]), _mm256_mul_ps(two, cx[k][2]));
            dqx[k] = _mm256_fmadd_ps(vv, tx, cx[k][1]);

            __m256 ty = _mm256_fmadd_ps(three, _mm256_mul_ps(vv, cy[k][3]), _mm256_mul_ps(two, cy[k][2]));
            dqy[k] = _mm256_fmadd_ps(vv, ty, cy[k][1]);

            __m256 tz = _mm256_fmadd_ps(three, _mm256_mul_ps(vv, cz[k][3]), _mm256_mul_ps(two, cz[k][2]));
            dqz[k] = _mm256_fmadd_ps(vv, tz, cz[k][1]);
        }

        // P(u,v) = q0 + u*(q1 + u*(q2 + u*q3))
        __m256 pxv = _mm256_fmadd_ps(uu, qx[3], qx[2]);
        pxv = _mm256_fmadd_ps(uu, pxv, qx[1]);
        pxv = _mm256_fmadd_ps(uu, pxv, qx[0]);

        __m256 pyv = _mm256_fmadd_ps(uu, qy[3], qy[2]);
        pyv = _mm256_fmadd_ps(uu, pyv, qy[1]);
        pyv = _mm256_fmadd_ps(uu, pyv, qy[0]);

        __m256 pzv = _mm256_fmadd_ps(uu, qz[3], qz[2]);
        pzv = _mm256_fmadd_ps(uu, pzv, qz[1]);
        pzv = _mm256_fmadd_ps(uu, pzv, qz[0]);

        // dP/du = q1 + u*(2*q2 + 3*u*q3)
        const __m256 two = _mm256_set1_ps(2.0f);
        const __m256 three = _mm256_set1_ps(3.0f);

        __m256 tx = _mm256_fmadd_ps(three, _mm256_mul_ps(uu, qx[3]), _mm256_mul_ps(two, qx[2]));
        __m256 duxv = _mm256_fmadd_ps(uu, tx, qx[1]);

        __m256 ty = _mm256_fmadd_ps(three, _mm256_mul_ps(uu, qy[3]), _mm256_mul_ps(two, qy[2]));
        __m256 duyv = _mm256_fmadd_ps(uu, ty, qy[1]);

        __m256 tz = _mm256_fmadd_ps(three, _mm256_mul_ps(uu, qz[3]), _mm256_mul_ps(two, qz[2]));
        __m256 duzv = _mm256_fmadd_ps(uu, tz, qz[1]);

        // dP/dv = dq0 + u*(dq1 + u*(dq2 + u*dq3))
        __m256 dvxv = _mm256_fmadd_ps(uu, dqx[3], dqx[2]);
        dvxv = _mm256_fmadd_ps(uu, dvxv, dqx[1]);
        dvxv = _mm256_fmadd_ps(uu, dvxv, dqx[0]);

        __m256 dvyv = _mm256_fmadd_ps(uu, dqy[3], dqy[2]);
        dvyv = _mm256_fmadd_ps(uu, dvyv, dqy[1]);
        dvyv = _mm256_fmadd_ps(uu, dvyv, dqy[0]);

        __m256 dvzv = _mm256_fmadd_ps(uu, dqz[3], dqz[2]);
        dvzv = _mm256_fmadd_ps(uu, dvzv, dqz[1]);
        dvzv = _mm256_fmadd_ps(uu, dvzv, dqz[0]);

        _mm256_storeu_ps(px, pxv);
        _mm256_storeu_ps(py, pyv);
        _mm256_storeu_ps(pz, pzv);
        _mm256_storeu_ps(dux, duxv);
        _mm256_storeu_ps(duy, duyv);
        _mm256_storeu_ps(duz, duzv);
        _mm256_storeu_ps(dvx, dvxv);
        _mm256_storeu_ps(dvy, dvyv);
        _mm256_storeu_ps(dvz, dvzv);
    }
};

// ---------- Parse teapot.bpt ----------
std::vector<Patch> loadTeapot(const std::string& path) {
    std::ifstream in(path);
    if (!in) {
        std::cerr << "Cannot open " << path << "\n";
        std::exit(1);
    }
    int numPatches = 0;
    in >> numPatches;
    std::vector<Patch> patches;
    patches.reserve(numPatches);
    for (int p = 0; p < numPatches; ++p) {
        Patch patch;
        int degU, degV;
        in >> degU >> degV;
        for (int i = 0; i < 16; ++i) {
            double x, y, z;
            in >> x >> y >> z;
            patch.cp[i] = Vec3(x, y, z);
        }
        patch.buildCoefficients();
        patches.push_back(patch);
    }
    return patches;
}

// ---------- Camera / coordinate transforms ----------
struct Camera {
    Vec3 eye, target, up;
    double fov; // vertical fov in radians
    int width, height;

    // cached axes
    Vec3 forward, right, camUp;
    double f; // focal length scale

    Camera(Vec3 eye_, Vec3 target_, Vec3 up_, double fov_deg, int w, int h)
        : eye(eye_), target(target_), up(up_), fov(fov_deg * M_PI / 180.0), width(w), height(h) {
        forward = normalize(target - eye);
        right = normalize(cross(forward, up));
        camUp = cross(right, forward);
        f = 1.0 / std::tan(fov / 2.0);
    }

    // World -> camera space
    Vec3 worldToCamera(const Vec3& p) const {
        Vec3 d = p - eye;
        return Vec3(dot(d, right), dot(d, camUp), dot(d, forward));
    }

    // Perspective projection: returns (screen_x, screen_y, 1/camera_z)
    Vec3 project(const Vec3& pc) const {
        double invZ = 1.0 / pc.z;
        double sx = pc.x * f * invZ;
        double sy = pc.y * f * invZ;
        double px = sx * (height * 0.5) + width * 0.5;
        double py = -sy * (height * 0.5) + height * 0.5;
        return Vec3(px, py, invZ);
    }
};

// ---------- Vertex / triangle ----------
struct Vertex {
    Vec3 pos;      // world position
    Vec3 normal;   // world normal
    Vec3 screen;   // (px, py, 1/cz)
};

using Triangle = std::array<Vertex, 3>;

// ---------- Evaluation mode ----------
enum class EvalMode { Bernstein, Horner, Batch4D };

// ---------- Classic tessellation (Bernstein or 3D Horner) ----------
std::vector<Triangle> tessellate(const std::vector<Patch>& patches, int tess,
                                 EvalMode mode, const Camera& cam) {
    std::vector<Triangle> tris;
    tris.reserve(patches.size() * tess * tess * 2);

    for (const Patch& patch : patches) {
        int gridW = tess + 1;
        std::vector<Vertex> grid(gridW * gridW);

        // 1) position evaluation
        for (int j = 0; j <= tess; ++j) {
            double v = j / (double)tess;
            for (int i = 0; i <= tess; ++i) {
                double u = i / (double)tess;
                Vec3 p = (mode == EvalMode::Horner)
                             ? patch.evalHorner(u, v)
                             : patch.evalBernstein(u, v);
                grid[j * gridW + i].pos = p;
            }
        }

        // 2) grid normals via finite differences (same post-processing for both modes)
        auto idx = [gridW](int i, int j) { return j * gridW + i; };
        for (int j = 0; j <= tess; ++j) {
            for (int i = 0; i <= tess; ++i) {
                Vec3 du, dv;
                if (i == 0) du = grid[idx(i + 1, j)].pos - grid[idx(i, j)].pos;
                else if (i == tess) du = grid[idx(i, j)].pos - grid[idx(i - 1, j)].pos;
                else du = grid[idx(i + 1, j)].pos - grid[idx(i - 1, j)].pos;

                if (j == 0) dv = grid[idx(i, j + 1)].pos - grid[idx(i, j)].pos;
                else if (j == tess) dv = grid[idx(i, j)].pos - grid[idx(i, j - 1)].pos;
                else dv = grid[idx(i, j + 1)].pos - grid[idx(i, j - 1)].pos;

                grid[idx(i, j)].normal = normalize(cross(du, dv));
            }
        }

        // 3) project to screen space
        for (auto& v : grid) {
            Vec3 pc = cam.worldToCamera(v.pos);
            v.screen = cam.project(pc);
        }

        // 4) build triangles
        for (int j = 0; j < tess; ++j) {
            for (int i = 0; i < tess; ++i) {
                Vertex a = grid[idx(i, j)];
                Vertex b = grid[idx(i + 1, j)];
                Vertex c = grid[idx(i, j + 1)];
                Vertex d = grid[idx(i + 1, j + 1)];

                tris.push_back(Triangle{ a, b, c });
                tris.push_back(Triangle{ b, d, c });
            }
        }
    }
    return tris;
}

// ---------- Framebuffer helpers ----------
struct Framebuffer {
    int width, height;
    std::vector<uint8_t> color; // RGB
    std::vector<double> zbuf;   // camera-space depth
    // Compact G-buffer retained after rasterisation for edge-aware AA.
    std::vector<float> normal;    // world normal, 3 floats per pixel
    std::vector<float> curvature; // geometric-curvature proxy
    std::vector<uint8_t> stencil; // edge candidate mask

    Framebuffer(int w, int h) : width(w), height(h) {
        color.assign(w * h * 3, 0);
        zbuf.assign(w * h, std::numeric_limits<double>::infinity());
        normal.assign(w * h * 3, 0.0f);
        curvature.assign(w * h, 0.0f);
        stencil.assign(w * h, 0);
    }

    void clear(uint8_t r = 0, uint8_t g = 0, uint8_t b = 0) {
        if (r == g && g == b) {
            std::fill(color.begin(), color.end(), r);
        } else {
            for (size_t i = 0; i + 2 < color.size(); i += 3) {
                color[i] = r;
                color[i + 1] = g;
                color[i + 2] = b;
            }
        }
        std::fill(zbuf.begin(), zbuf.end(), std::numeric_limits<double>::infinity());
        std::fill(normal.begin(), normal.end(), 0.0f);
        std::fill(curvature.begin(), curvature.end(), 0.0f);
        std::fill(stencil.begin(), stencil.end(), 0);
    }

    inline void setPixel(int x, int y, const uint8_t rgb[3]) {
        if (x < 0 || x >= width || y < 0 || y >= height) return;
        int idx = (y * width + x) * 3;
        color[idx + 0] = rgb[0];
        color[idx + 1] = rgb[1];
        color[idx + 2] = rgb[2];
    }

    inline void setGBuffer(int x, int y, const Vec3& n, float c) {
        const int p = y * width + x;
        normal[p * 3 + 0] = static_cast<float>(n.x);
        normal[p * 3 + 1] = static_cast<float>(n.y);
        normal[p * 3 + 2] = static_cast<float>(n.z);
        curvature[p] = c;
    }
};

// Draw a 2x2 point splat with a z-test.
inline void drawPoint(int cx, int cy, double z, const uint8_t rgb[3], Framebuffer& fb) {
    for (int dy = 0; dy < 2; ++dy) {
        for (int dx = 0; dx < 2; ++dx) {
            int x = cx + dx;
            int y = cy + dy;
            if (x < 0 || x >= fb.width || y < 0 || y >= fb.height) continue;
            int pix = y * fb.width + x;
            if (z < fb.zbuf[pix]) {
                fb.zbuf[pix] = z;
                fb.setPixel(x, y, rgb);
            }
        }
    }
}

// Draw a short line with perspective-correct 1/z interpolation.
inline void drawLine(const Vec3& p0, const Vec3& p1, const uint8_t rgb[3], Framebuffer& fb) {
    double dx = p1.x - p0.x;
    double dy = p1.y - p0.y;
    int steps = (int)std::ceil(std::max(std::abs(dx), std::abs(dy)));
    if (steps == 0) return;

    for (int s = 0; s <= steps; ++s) {
        double t = s / static_cast<double>(steps);
        double x = p0.x + dx * t;
        double y = p0.y + dy * t;
        double invZ = p0.z + (p1.z - p0.z) * t;
        if (invZ <= 0.0) continue;
        double z = 1.0 / invZ;

        int ix = (int)x;
        int iy = (int)y;
        if (ix < 0 || ix >= fb.width || iy < 0 || iy >= fb.height) continue;

        int pix = iy * fb.width + ix;
        if (z < fb.zbuf[pix]) {
            fb.zbuf[pix] = z;
            fb.setPixel(ix, iy, rgb);
        }
    }
}

// ---------- Batch 4D point + tangent renderer ----------
//
// Instead of building triangles and filling them, this path evaluates all
// surface points and their tangents in one AVX-batched compute pass and then
// draws the points and short tangent lines directly.  Because there is no
// triangle rasterization, it is dramatically faster and maps directly to a
// GPU vertex/tangent kernel.
void renderBatch4DPoints(const std::vector<Patch>& patches, int tess,
                         const Camera& cam, Framebuffer& fb, const Vec3& lightDir,
                         bool blueMode = false, bool drawTangents = true) {
    // Lift every patch to AVX-friendly 4D coefficients once.
    std::vector<PatchAVX> patchesAVX(patches.size());
    for (size_t i = 0; i < patches.size(); ++i) {
        patchesAVX[i].build(patches[i]);
    }

    const float tangentScale = 0.04f; // world-space tangent visualization length

    int gridW = tess + 1;
    int gridSize = gridW * gridW;
    int padded = ((gridSize + 7) / 8) * 8;

    // Reusable evaluation buffers (no allocation after the first call)
    thread_local std::vector<float> u_buf, v_buf;
    thread_local std::vector<float> px_buf, py_buf, pz_buf;
    thread_local std::vector<float> dux_buf, duy_buf, duz_buf;
    thread_local std::vector<float> dvx_buf, dvy_buf, dvz_buf;

    u_buf.resize(padded);  v_buf.resize(padded);
    px_buf.resize(padded); py_buf.resize(padded); pz_buf.resize(padded);
    dux_buf.resize(padded); duy_buf.resize(padded); duz_buf.resize(padded);
    dvx_buf.resize(padded); dvy_buf.resize(padded); dvz_buf.resize(padded);

    float* u = u_buf.data();
    float* v = v_buf.data();
    float* px = px_buf.data();
    float* py = py_buf.data();
    float* pz = pz_buf.data();
    float* dux = dux_buf.data();
    float* duy = duy_buf.data();
    float* duz = duz_buf.data();
    float* dvx = dvx_buf.data();
    float* dvy = dvy_buf.data();
    float* dvz = dvz_buf.data();

    const uint8_t red[3]   = { 200,  40,  40 };
    const uint8_t green[3] = {  40, 200,  40 };
    const uint8_t white[3] = { 220, 220, 220 };

    for (size_t pi = 0; pi < patchesAVX.size(); ++pi) {
        const PatchAVX& pavx = patchesAVX[pi];

        // 1) fill parameter arrays
        for (int idx = 0; idx < gridSize; ++idx) {
            int j = idx / gridW;
            int i = idx - j * gridW;
            u[idx] = i / static_cast<float>(tess);
            v[idx] = j / static_cast<float>(tess);
        }
        for (int idx = gridSize; idx < padded; ++idx) {
            u[idx] = u[gridSize - 1];
            v[idx] = v[gridSize - 1];
        }

        // 2) GPU-style dispatch: evaluate 8 points at once
        for (int i = 0; i < padded; i += 8) {
            pavx.eval8(&u[i], &v[i],
                       &px[i], &py[i], &pz[i],
                       &dux[i], &duy[i], &duz[i],
                       &dvx[i], &dvy[i], &dvz[i]);
        }

        // 3) draw every point and its two tangent lines
        auto at = [gridW](int i, int j) { return j * gridW + i; };
        for (int j = 0; j <= tess; ++j) {
            for (int i = 0; i <= tess; ++i) {
                int ix = at(i, j);

                Vec3 pos(px[ix], py[ix], pz[ix]);
                Vec3 du(dux[ix], duy[ix], duz[ix]);
                Vec3 dv(dvx[ix], dvy[ix], dvz[ix]);

                // Exact normal from the two parametric tangents
                Vec3 n = cross(du, dv);
                if (length(n) < 1e-12) {
                    // Degenerate points (e.g. the lid center): fall back to
                    // finite differences using the already-evaluated neighbours.
                    Vec3 pu, pv;
                    if (i == 0) pu = Vec3(px[ix + 1], py[ix + 1], pz[ix + 1]) - pos;
                    else if (i == tess) pu = pos - Vec3(px[ix - 1], py[ix - 1], pz[ix - 1]);
                    else pu = Vec3(px[ix + 1], py[ix + 1], pz[ix + 1]) - Vec3(px[ix - 1], py[ix - 1], pz[ix - 1]);

                    if (j == 0) pv = Vec3(px[ix + gridW], py[ix + gridW], pz[ix + gridW]) - pos;
                    else if (j == tess) pv = pos - Vec3(px[ix - gridW], py[ix - gridW], pz[ix - gridW]);
                    else pv = Vec3(px[ix + gridW], py[ix + gridW], pz[ix + gridW]) - Vec3(px[ix - gridW], py[ix - gridW], pz[ix - gridW]);

                    n = cross(pu, pv);
                }
                n = normalize(n);

                double diff = std::max(0.0, dot(n, lightDir));
                uint8_t pointColor[3];
                if (blueMode) {
                    pointColor[0] = (uint8_t)std::clamp(10.0 +  60.0 * diff, 0.0, 255.0);
                    pointColor[1] = (uint8_t)std::clamp(10.0 + 120.0 * diff, 0.0, 255.0);
                    pointColor[2] = (uint8_t)std::clamp(40.0 + 215.0 * diff, 0.0, 255.0);
                } else {
                    uint8_t shade = (uint8_t)std::clamp(30.0 + 200.0 * diff, 0.0, 255.0);
                    pointColor[0] = pointColor[1] = pointColor[2] = shade;
                }

                Vec3 sp = cam.project(cam.worldToCamera(pos));
                drawPoint((int)sp.x, (int)sp.y, 1.0 / sp.z, pointColor, fb);

                if (drawTangents) {
                    const uint8_t* uColor = blueMode ? white : red;
                    const uint8_t* vColor = blueMode ? white : green;

                    Vec3 sp_u = cam.project(cam.worldToCamera(pos + du * tangentScale));
                    drawLine(sp, sp_u, uColor, fb);

                    Vec3 sp_v = cam.project(cam.worldToCamera(pos + dv * tangentScale));
                    drawLine(sp, sp_v, vColor, fb);
                }
            }
        }
    }
}

// ---------- Triangle rasterizer ----------
inline double edgeFunction(const Vec3& a, const Vec3& b, const Vec3& c) {
    return (c.x - a.x) * (b.y - a.y) - (c.y - a.y) * (b.x - a.x);
}

void rasterize(const std::vector<Triangle>& tris, Framebuffer& fb, const Vec3& lightDir) {
    for (const auto& tri : tris) {
        const Vertex& v0 = tri[0];
        const Vertex& v1 = tri[1];
        const Vertex& v2 = tri[2];

        double area2 = edgeFunction(v0.screen, v1.screen, v2.screen);
        if (area2 == 0.0) continue;

        int minX = (int)std::floor(std::min({ v0.screen.x, v1.screen.x, v2.screen.x }));
        int maxX = (int)std::ceil (std::max({ v0.screen.x, v1.screen.x, v2.screen.x }));
        int minY = (int)std::floor(std::min({ v0.screen.y, v1.screen.y, v2.screen.y }));
        int maxY = (int)std::ceil (std::max({ v0.screen.y, v1.screen.y, v2.screen.y }));

        minX = std::max(minX, 0); minY = std::max(minY, 0);
        maxX = std::min(maxX, fb.width - 1); maxY = std::min(maxY, fb.height - 1);

        for (int y = minY; y <= maxY; ++y) {
            for (int x = minX; x <= maxX; ++x) {
                Vec3 p(x + 0.5, y + 0.5, 0.0);
                double w0 = edgeFunction(v1.screen, v2.screen, p);
                double w1 = edgeFunction(v2.screen, v0.screen, p);
                double w2 = edgeFunction(v0.screen, v1.screen, p);

                if ((w0 < 0.0 || w1 < 0.0 || w2 < 0.0) && (w0 > 0.0 || w1 > 0.0 || w2 > 0.0))
                    continue;

                w0 /= area2; w1 /= area2; w2 /= area2;

                double invZ = w0 * v0.screen.z + w1 * v1.screen.z + w2 * v2.screen.z;
                if (invZ <= 0.0) continue;
                double z = 1.0 / invZ;

                int pix = y * fb.width + x;
                if (z < fb.zbuf[pix]) {
                    fb.zbuf[pix] = z;

                    Vec3 n = normalize(w0 * v0.normal + w1 * v1.normal + w2 * v2.normal);
                    double diff = std::max(0.0, dot(n, lightDir));
                    uint8_t c = (uint8_t)std::clamp(30.0 + 200.0 * diff, 0.0, 255.0);
                    uint8_t rgb[3] = { c, c, c };
                    fb.setPixel(x, y, rgb);
                }
            }
        }
    }
}

void savePPM(const std::string& path, const Framebuffer& fb) {
    std::ofstream out(path, std::ios::binary);
    out << "P6\n" << fb.width << " " << fb.height << "\n255\n";
    out.write(reinterpret_cast<const char*>(fb.color.data()), fb.color.size());
}

// ==================================================================
// Interactive pipeline: clean mesh -> curvature-spike cleanup -> bilateral normal filter ->
// Blinn-Phong shading.  All software, no OpenGL.
// ==================================================================

// ---------- Clean low-poly mesh ----------
struct Mesh {
    std::vector<Vec3> pos;
    std::vector<Vec3> rawNormal;                   // Pass 1 output
    std::vector<Vec3> filteredNormal;              // Pass 2 output
    std::vector<double> curvature;                 // local geometric-curvature proxy
    std::vector<std::array<int32_t, 3>> tris;
    std::vector<int32_t> nbrOffset;                // CSR adjacency (size V+1)
    std::vector<int32_t> nbrList;
};

void stitchSmoothPatchNormals(Mesh& m);

void computeRawNormals(Mesh& m) {
    m.rawNormal.assign(m.pos.size(), Vec3());
    for (const auto& t : m.tris) {
        Vec3 fn = cross(m.pos[t[1]] - m.pos[t[0]], m.pos[t[2]] - m.pos[t[0]]);
        m.rawNormal[t[0]] += fn;
        m.rawNormal[t[1]] += fn;
        m.rawNormal[t[2]] += fn;
    }
    for (auto& n : m.rawNormal) {
        if (length(n) < 1e-12) n = Vec3(0, 0, 1);
        else n = normalize(n);
    }
}

// Bezier patches meet with duplicate boundary vertices.  Average only the
// compatible normals at those coincident positions, so a smooth patch seam
// cannot show up as a lighting stripe.  Normals more than 45 degrees apart
// are deliberately left alone: that is an actual feature edge, not noise.
void stitchCompatibleNormals(const std::vector<Vec3>& pos, std::vector<Vec3>& normals) {
    using Key = std::array<long long, 3>;
    std::map<Key, std::vector<int32_t>> groups;
    for (int32_t i = 0; i < static_cast<int32_t>(pos.size()); ++i) {
        const Vec3& p = pos[i];
        groups[{std::llround(p.x * 1e6), std::llround(p.y * 1e6),
                std::llround(p.z * 1e6)}].push_back(i);
    }

    const double compatibleDot = std::cos(45.0 * 3.141592653589793 / 180.0);
    std::vector<Vec3> stitched = normals;
    for (const auto& entry : groups) {
        const auto& g = entry.second;
        if (g.size() < 2) continue;
        for (int32_t v : g) {
            Vec3 sum;
            for (int32_t u : g)
                if (dot(normals[v], normals[u]) >= compatibleDot)
                    sum += normals[u];
            if (length(sum) > 1e-12) stitched[v] = normalize(sum);
        }
    }
    normals.swap(stitched);
}

void stitchSmoothPatchNormals(Mesh& m) {
    stitchCompatibleNormals(m.pos, m.rawNormal);
}

// Build a per-patch grid mesh directly from the Bezier surface.  With unify
// enabled, coincident patch-boundary samples become one shared vertex, so the
// downstream normal and curvature passes see a single connected surface.
Mesh buildCleanMesh(const std::vector<Patch>& patches, int tess, bool unify) {
    Mesh m;
    const int gridW = tess + 1;
    const int R = 3; // bilateral neighbourhood radius in grid steps
    using Key = std::array<long long, 3>;
    constexpr double weldTolerance = 2e-4;
    constexpr double keyScale = 1e4;
    std::map<Key, int32_t> weldedVertex;
    std::vector<std::vector<int32_t>> adjacency;

    auto idx = [gridW](int i, int j) { return j * gridW + i; };
    auto addVertex = [&](const Vec3& p) -> int32_t {
        if (unify) {
            const Key center = {std::llround(p.x * keyScale), std::llround(p.y * keyScale),
                                std::llround(p.z * keyScale)};
            // Search neighbouring hash cells too: quantisation must not make
            // two mathematically identical seam samples miss each other.
            for (int dz = -1; dz <= 1; ++dz)
                for (int dy = -1; dy <= 1; ++dy)
                    for (int dx = -1; dx <= 1; ++dx) {
                        const Key probe = {center[0] + dx, center[1] + dy, center[2] + dz};
                        auto it = weldedVertex.find(probe);
                        if (it != weldedVertex.end() &&
                            length(m.pos[it->second] - p) <= weldTolerance)
                            return it->second;
                    }
            const int32_t result = static_cast<int32_t>(m.pos.size());
            m.pos.push_back(p);
            adjacency.emplace_back();
            weldedVertex.emplace(center, result);
            return result;
        }
        const int32_t result = static_cast<int32_t>(m.pos.size());
        m.pos.push_back(p);
        adjacency.emplace_back();
        return result;
    };
    auto connect = [&](int32_t a, int32_t b) {
        if (a != b) { adjacency[a].push_back(b); adjacency[b].push_back(a); }
    };

    for (const Patch& patch : patches) {
        // Sample the analytic Bezier surface at the grid vertices.
        std::vector<Vec3> clean(gridW * gridW);
        std::vector<int32_t> grid(gridW * gridW);
        for (int j = 0; j <= tess; ++j)
            for (int i = 0; i <= tess; ++i)
                clean[idx(i, j)] = patch.evalHorner(i / (double)tess, j / (double)tess);

        // Keep the exact sampled positions.  Do not inject random noise.
        for (int k = 0; k < gridW * gridW; ++k)
            grid[k] = addVertex(clean[k]);

        // Triangles
        for (int j = 0; j < tess; ++j) {
            for (int i = 0; i < tess; ++i) {
                int a = grid[idx(i, j)], b = grid[idx(i + 1, j)];
                int c = grid[idx(i, j + 1)], d = grid[idx(i + 1, j + 1)];
                m.tris.push_back({ a, b, c });
                m.tris.push_back({ b, d, c });
            }
        }

        // Neighbours up to R grid steps away.  When a boundary vertex has
        // been welded, contributions from every adjoining patch accumulate in
        // this same global adjacency list.
        for (int j = 0; j <= tess; ++j) {
            for (int i = 0; i <= tess; ++i) {
                for (int dj = -R; dj <= R; ++dj) {
                    for (int di = -R; di <= R; ++di) {
                        if (di == 0 && dj == 0) continue;
                        int ni = i + di, nj = j + dj;
                        if (ni < 0 || ni > tess || nj < 0 || nj > tess) continue;
                        connect(grid[idx(i, j)], grid[idx(ni, nj)]);
                    }
                }
            }
        }
    }
    m.nbrOffset.reserve(m.pos.size() + 1);
    for (auto& neighbours : adjacency) {
        std::sort(neighbours.begin(), neighbours.end());
        neighbours.erase(std::unique(neighbours.begin(), neighbours.end()), neighbours.end());
        m.nbrOffset.push_back(static_cast<int32_t>(m.nbrList.size()));
        m.nbrList.insert(m.nbrList.end(), neighbours.begin(), neighbours.end());
    }
    m.nbrOffset.push_back(static_cast<int32_t>(m.nbrList.size()));

    // Pass 1: accumulate raw face normals into vertex normals.
    computeRawNormals(m);
    stitchSmoothPatchNormals(m);
    m.filteredNormal = m.rawNormal;
    return m;
}

// Remove only isolated curvature spikes, without changing the overall teapot
// shape.  Curvature is approximated by the distance to a Gaussian-weighted
// neighbour centroid.  A spatial EWMA gives each vertex a local expected
// curvature; vertices that rise distinctly above that trend move a *small*
// step toward the centroid.  On an already smooth Bezier mesh this is nearly
// a no-op, which is intentional.
void smoothCurvatureSpikesEWMA(Mesh& m) {
    const size_t n = m.pos.size();
    if (n == 0) return;

    std::vector<Vec3> centroid(n);
    std::vector<double> curvature(n, 0.0), localScale(n, 1.0);

#pragma omp parallel for if(n > 4096)
    for (size_t v = 0; v < n; ++v) {
        Vec3 sum;
        double wsum = 0.0, scaleSum = 0.0;
        for (int32_t k = m.nbrOffset[v]; k < m.nbrOffset[v + 1]; ++k) {
            const int32_t u = m.nbrList[k];
            const Vec3 d = m.pos[u] - m.pos[v];
            const double d2 = dot(d, d);
            // One grid step is normally close to 0.1 world units.
            const double w = std::exp(-d2 / (2.0 * 0.18 * 0.18));
            sum += m.pos[u] * w;
            wsum += w;
            scaleSum += std::sqrt(d2);
        }
        centroid[v] = wsum > 0.0 ? sum / wsum : m.pos[v];
        localScale[v] = std::max(1e-6, scaleSum /
                                  std::max<int32_t>(1, m.nbrOffset[v + 1] - m.nbrOffset[v]));
        curvature[v] = length(m.pos[v] - centroid[v]) / localScale[v];
    }
    m.curvature = curvature;

    std::vector<double> ewma(n, 0.0);
    constexpr double alpha = 0.35; // current curvature weight
#pragma omp parallel for if(n > 4096)
    for (size_t v = 0; v < n; ++v) {
        double weighted = curvature[v];
        double weight = 1.0;
        for (int32_t k = m.nbrOffset[v]; k < m.nbrOffset[v + 1]; ++k) {
            const int32_t u = m.nbrList[k];
            const double d2 = dot(m.pos[u] - m.pos[v], m.pos[u] - m.pos[v]);
            const double w = std::exp(-d2 / (2.0 * 0.25 * 0.25));
            weighted += curvature[u] * w;
            weight += w;
        }
        const double neighbourTrend = weighted / weight;
        ewma[v] = alpha * curvature[v] + (1.0 - alpha) * neighbourTrend;
    }

    std::vector<Vec3> updated = m.pos;
#pragma omp parallel for if(n > 4096)
    for (size_t v = 0; v < n; ++v) {
        // The relative threshold preserves deliberate, broad high-curvature
        // regions such as the spout and lid while catching one-vertex kinks.
        const double excess = curvature[v] - ewma[v] * 1.18;
        if (excess <= 0.0) continue;
        const double amount = std::clamp(excess * 0.025, 0.0, 0.035);
        updated[v] = m.pos[v] * (1.0 - amount) + centroid[v] * amount;
    }
    m.pos.swap(updated);
}

// Pass 2: bilateral filter on the normal field.
//   weight = exp(-|p_n - p_c|^2 / (2 sigmaS^2))
//          * exp(-(1 - dot(N_c, N_n))^2 / (2 sigmaR^2))
void bilateralFilterNormals(Mesh& m, double sigmaS, double sigmaR) {
    const double inv2s2 = 1.0 / (2.0 * sigmaS * sigmaS);
    const double inv2r2 = 1.0 / (2.0 * sigmaR * sigmaR);
    const size_t n = m.pos.size();

#pragma omp parallel for if(n > 4096)
    for (size_t v = 0; v < n; ++v) {
        const Vec3& Nc = m.rawNormal[v];
        Vec3 sum = Nc; // centre sample with unit weight
        double wsum = 1.0;
        for (int32_t k = m.nbrOffset[v]; k < m.nbrOffset[v + 1]; ++k) {
            int32_t u = m.nbrList[k];
            Vec3 d = m.pos[u] - m.pos[v];
            double ws = std::exp(-dot(d, d) * inv2s2);
            double dr = 1.0 - std::clamp(dot(Nc, m.rawNormal[u]), -1.0, 1.0);
            double wr = std::exp(-dr * dr * inv2r2);
            double w = ws * wr;
            sum += m.rawNormal[u] * w;
            wsum += w;
        }
        // Clamp the correction and adapt its ratio.  A high-curvature area is
        // more likely to be a genuine feature, while a flat area can safely
        // accept a little more normal denoising.
        const Vec3 bilateral = normalize(sum / wsum);
        const double disagreement = std::clamp(1.0 - dot(Nc, bilateral), 0.0, 1.0);
        const double curveGate = 1.0 / (1.0 + 4.0 * m.curvature[v]);
        const double ratio = std::clamp((0.03 + 0.22 * disagreement /
                                         std::max(0.01, sigmaR)) * curveGate,
                                        0.01, 0.18);
        m.filteredNormal[v] = normalize(Nc * (1.0 - ratio) + bilateral * ratio);
    }
    stitchCompatibleNormals(m.pos, m.filteredNormal);
}

// ---------- Vertex stage: project once per frame, premultiply attributes ----------
struct VSOut {
    float sx, sy, invZ;   // screen x, y, 1/z_cam
    float nx, ny, nz;     // world normal * invZ
    float px, py, pz;     // world position * invZ
    float curvature;      // local curvature proxy * invZ
};

void vertexStage(const Mesh& m, const std::vector<Vec3>& normals,
                 const Camera& cam, std::vector<VSOut>& out) {
    const size_t n = m.pos.size();
    out.resize(n);
#pragma omp parallel for if(n > 4096)
    for (size_t i = 0; i < n; ++i) {
        Vec3 sp = cam.project(cam.worldToCamera(m.pos[i]));
        float iz = static_cast<float>(sp.z);
        VSOut& o = out[i];
        o.sx = static_cast<float>(sp.x);
        o.sy = static_cast<float>(sp.y);
        o.invZ = iz;
        o.nx = static_cast<float>(normals[i].x * iz);
        o.ny = static_cast<float>(normals[i].y * iz);
        o.nz = static_cast<float>(normals[i].z * iz);
        o.px = static_cast<float>(m.pos[i].x * iz);
        o.py = static_cast<float>(m.pos[i].y * iz);
        o.pz = static_cast<float>(m.pos[i].z * iz);
        o.curvature = static_cast<float>(m.curvature[i] * iz);
    }
}

// ---------- Pass 3: Blinn-Phong triangle rasterizer ----------
struct ShadeParams {
    Vec3 eye, lightPos;
    float baseR, baseG, baseB;
    float ambient, specStrength, shininess;
    float lightIntensity, airExtinction, baseRoughness, curvatureRoughness;
};

void rasterizeBlinnPhong(const Mesh& m, const std::vector<VSOut>& vs,
                         Framebuffer& fb, const ShadeParams& sp) {
    int bands = 1;
#ifdef _OPENMP
    bands = std::min(omp_get_max_threads(), 8);
#endif
    const int bandH = (fb.height + bands - 1) / bands;

#pragma omp parallel for schedule(static)
    for (int band = 0; band < bands; ++band) {
        const int yLo = band * bandH;
        const int yHi = std::min(fb.height, yLo + bandH);

        for (const auto& tri : m.tris) {
            const VSOut& va = vs[tri[0]];
            const VSOut& vb = vs[tri[1]];
            const VSOut& vc = vs[tri[2]];
            if (va.invZ <= 0.0f || vb.invZ <= 0.0f || vc.invZ <= 0.0f) continue;

            const Vec3 a(va.sx, va.sy, 0), b(vb.sx, vb.sy, 0), c(vc.sx, vc.sy, 0);
            double area2 = edgeFunction(a, b, c);
            if (area2 == 0.0) continue;

            int minX = std::max(0, (int)std::floor(std::min({ a.x, b.x, c.x })));
            int maxX = std::min(fb.width - 1, (int)std::ceil(std::max({ a.x, b.x, c.x })));
            int minY = std::max(yLo, (int)std::floor(std::min({ a.y, b.y, c.y })));
            int maxY = std::min(yHi - 1, (int)std::ceil(std::max({ a.y, b.y, c.y })));
            if (minX > maxX || minY > maxY) continue;

            for (int y = minY; y <= maxY; ++y) {
                for (int x = minX; x <= maxX; ++x) {
                    Vec3 p(x + 0.5, y + 0.5, 0.0);
                    double w0 = edgeFunction(b, c, p);
                    double w1 = edgeFunction(c, a, p);
                    double w2 = edgeFunction(a, b, p);
                    if ((w0 < 0.0 || w1 < 0.0 || w2 < 0.0) &&
                        (w0 > 0.0 || w1 > 0.0 || w2 > 0.0))
                        continue;

                    w0 /= area2; w1 /= area2; w2 /= area2;

                    double invZ = w0 * va.invZ + w1 * vb.invZ + w2 * vc.invZ;
                    if (invZ <= 0.0) continue;
                    double z = 1.0 / invZ;

                    int pix = y * fb.width + x;
                    if (z >= fb.zbuf[pix]) continue;
                    fb.zbuf[pix] = z;

                    // Perspective-correct attributes (stored premultiplied by invZ)
                    Vec3 N(w0 * va.nx + w1 * vb.nx + w2 * vc.nx,
                           w0 * va.ny + w1 * vb.ny + w2 * vc.ny,
                           w0 * va.nz + w1 * vb.nz + w2 * vc.nz);
                    Vec3 P(w0 * va.px + w1 * vb.px + w2 * vc.px,
                           w0 * va.py + w1 * vb.py + w2 * vc.py,
                           w0 * va.pz + w1 * vb.pz + w2 * vc.pz);
                    N = normalize(N * z);
                    P = P * z;
                    const double curvature = std::max(0.0,
                        (w0 * va.curvature + w1 * vb.curvature + w2 * vc.curvature) * z);

                    Vec3 V = normalize(sp.eye - P);
                    if (dot(N, V) < 0.0) N = N * -1.0; // two-sided lighting

                    // Point-light radiance: inverse-square falloff combined
                    // with Beer-Lambert atmospheric transmission.
                    Vec3 toLight = sp.lightPos - P;
                    const double distance2 = std::max(0.04, dot(toLight, toLight));
                    const double distance = std::sqrt(distance2);
                    Vec3 L = toLight / distance;
                    const double transmission = std::exp(-sp.airExtinction * distance);
                    const double radiance = sp.lightIntensity * transmission / distance2;
                    double ndl = std::max(0.0, dot(N, L));
                    Vec3 H = normalize(L + V);
                    // Curvature acts as a geometry-derived roughness term:
                    // narrow highlights on broad smooth areas, wider ones at
                    // rapidly changing surface regions.
                    const double roughness = std::clamp(
                        sp.baseRoughness + sp.curvatureRoughness * curvature, 0.08, 0.85);
                    const double effectiveShininess = std::max(2.0,
                        sp.shininess / (1.0 + 5.0 * roughness * roughness));
                    double spec = std::pow(std::max(0.0, dot(N, H)), effectiveShininess)
                                  * sp.specStrength * radiance;

                    double shade = sp.ambient + ndl * radiance;
                    uint8_t rgb[3] = {
                        (uint8_t)std::clamp(255.0 * (shade * sp.baseR + spec), 0.0, 255.0),
                        (uint8_t)std::clamp(255.0 * (shade * sp.baseG + spec), 0.0, 255.0),
                        (uint8_t)std::clamp(255.0 * (shade * sp.baseB + spec), 0.0, 255.0)
                    };
                    fb.setPixel(x, y, rgb);
                    fb.setGBuffer(x, y, N, static_cast<float>(curvature));
                }
            }
        }
    }
}

// ---------- Geometry-guided local AA --------------------------------------
// This is deliberately *not* MSAA: the rasteriser remains single-sample.
// Global FXAA handles all screen edges.  Adaptive AA is reserved for the
// object/background silhouette plus analysed sharp geometric events.
inline float luminanceAt(const std::vector<uint8_t>& c, int p) {
    return (0.299f * c[p * 3] + 0.587f * c[p * 3 + 1] + 0.114f * c[p * 3 + 2]) / 255.0f;
}

inline bool validPixel(const Framebuffer& fb, int p) {
    return std::isfinite(fb.zbuf[p]);
}

void buildSharpFeatureStencil(Framebuffer& fb) {
    constexpr float normalBend = 0.07f; // 1 - dot(Np, Nq)
    constexpr double depthJump = 0.035;
    for (int y = 0; y < fb.height; ++y) {
        for (int x = 0; x < fb.width; ++x) {
            const int p = y * fb.width + x;
            if (!validPixel(fb, p)) continue;
            int backgroundNeighbours = 0;
            double maxDepthJump = 0.0;
            float maxNormalBend = 0.0f;
            constexpr std::array<std::array<int, 2>, 4> neighbours =
                {{{{-1, 0}}, {{1, 0}}, {{0, -1}}, {{0, 1}}}};
            for (const auto& o : neighbours) {
                const int nx = x + o[0], ny = y + o[1];
                if (nx < 0 || nx >= fb.width || ny < 0 || ny >= fb.height) {
                    ++backgroundNeighbours;
                    continue;
                }
                const int q = ny * fb.width + nx;
                if (!validPixel(fb, q)) { ++backgroundNeighbours; continue; }
                const double relativeDepth = std::abs(fb.zbuf[p] - fb.zbuf[q]) /
                    std::max(0.01, std::min(fb.zbuf[p], fb.zbuf[q]));
                const float ndot = fb.normal[p * 3] * fb.normal[q * 3] +
                    fb.normal[p * 3 + 1] * fb.normal[q * 3 + 1] +
                    fb.normal[p * 3 + 2] * fb.normal[q * 3 + 2];
                maxDepthJump = std::max(maxDepthJump, relativeDepth);
                maxNormalBend = std::max(maxNormalBend, 1.0f - std::clamp(ndot, -1.0f, 1.0f));
            }
            const float curvature = fb.curvature[p];
            // Object/background contact is a real coverage edge even when it
            // is geometrically smooth, so adaptive AA includes it.  It gets a
            // lower score than a tight bend; apertures and hard contacts get
            // the stronger local resolve.
            const bool silhouette = backgroundNeighbours >= 1;
            const bool apertureOrCorner = backgroundNeighbours >= 2 ||
                (backgroundNeighbours >= 1 && curvature > 0.07f && maxNormalBend > 0.04f);
            const bool abruptBend = curvature > 0.08f && maxNormalBend > normalBend;
            const bool occlusionKink = maxDepthJump > depthJump && maxNormalBend > 0.04f;
            if (!(silhouette || apertureOrCorner || abruptBend || occlusionKink)) continue;

            const float score = std::max({
                curvature / 0.16f,
                maxNormalBend / 0.20f,
                static_cast<float>(maxDepthJump / 0.08),
                silhouette ? 0.35f : 0.0f,
                backgroundNeighbours >= 2 ? 1.0f : 0.0f
            });
            fb.stencil[p] = static_cast<uint8_t>(std::clamp(score * 255.0f, 1.0f, 255.0f));
        }
    }
}

// Bilinear reads let the FXAA resolve move along the estimated edge instead
// of averaging a fixed horizontal or vertical pair.  This avoids the dotted
// rim artefacts produced by the previous cross-shaped blur.
Vec3 sampleColorBilinear(const std::vector<uint8_t>& source, int width, int height,
                         float x, float y) {
    x = std::clamp(x, 0.0f, static_cast<float>(width - 1));
    y = std::clamp(y, 0.0f, static_cast<float>(height - 1));
    const int x0 = static_cast<int>(std::floor(x)), y0 = static_cast<int>(std::floor(y));
    const int x1 = std::min(x0 + 1, width - 1), y1 = std::min(y0 + 1, height - 1);
    const float tx = x - x0, ty = y - y0;
    auto at = [&](int sx, int sy) {
        const int p = (sy * width + sx) * 3;
        return Vec3(source[p], source[p + 1], source[p + 2]);
    };
    const Vec3 top = at(x0, y0) * (1.0 - tx) + at(x1, y0) * tx;
    const Vec3 bottom = at(x0, y1) * (1.0 - tx) + at(x1, y1) * tx;
    return top * (1.0 - ty) + bottom * ty;
}

inline float luminance(const Vec3& c) {
    return static_cast<float>((0.299 * c.x + 0.587 * c.y + 0.114 * c.z) / 255.0);
}

// Compact FXAA 3-style directional resolve.  The candidate is accepted only
// if its luma remains inside the local 3x3 range, which avoids washing out a
// narrow specular highlight or crossing an unrelated edge.
Vec3 resolveFXAA(const std::vector<uint8_t>& source, int width, int height, int x, int y) {
    const Vec3 rgbM = sampleColorBilinear(source, width, height, x, y);
    const Vec3 rgbNW = sampleColorBilinear(source, width, height, x - 1, y - 1);
    const Vec3 rgbNE = sampleColorBilinear(source, width, height, x + 1, y - 1);
    const Vec3 rgbSW = sampleColorBilinear(source, width, height, x - 1, y + 1);
    const Vec3 rgbSE = sampleColorBilinear(source, width, height, x + 1, y + 1);
    const float lumaM = luminance(rgbM), lumaNW = luminance(rgbNW), lumaNE = luminance(rgbNE);
    const float lumaSW = luminance(rgbSW), lumaSE = luminance(rgbSE);
    const float lumaMin = std::min({lumaM, lumaNW, lumaNE, lumaSW, lumaSE});
    const float lumaMax = std::max({lumaM, lumaNW, lumaNE, lumaSW, lumaSE});
    if (lumaMax - lumaMin < std::max(0.0312f, lumaMax * 0.125f)) return rgbM;

    float dirX = -((lumaNW + lumaNE) - (lumaSW + lumaSE));
    float dirY =  ((lumaNW + lumaSW) - (lumaNE + lumaSE));
    const float reduce = std::max((lumaNW + lumaNE + lumaSW + lumaSE) * 0.03125f, 1.0f / 128.0f);
    const float invMinDir = 1.0f / (std::min(std::abs(dirX), std::abs(dirY)) + reduce);
    dirX = std::clamp(dirX * invMinDir, -8.0f, 8.0f);
    dirY = std::clamp(dirY * invMinDir, -8.0f, 8.0f);

    const Vec3 rgbA = 0.5 * (sampleColorBilinear(source, width, height, x + dirX * (1.0f / 3.0f - 0.5f), y + dirY * (1.0f / 3.0f - 0.5f)) +
                             sampleColorBilinear(source, width, height, x + dirX * (2.0f / 3.0f - 0.5f), y + dirY * (2.0f / 3.0f - 0.5f)));
    const Vec3 rgbB = rgbA * 0.5 + 0.25 *
        (sampleColorBilinear(source, width, height, x + dirX * -0.5f, y + dirY * -0.5f) +
         sampleColorBilinear(source, width, height, x + dirX *  0.5f, y + dirY *  0.5f));
    const float lumaB = luminance(rgbB);
    return (lumaB < lumaMin || lumaB > lumaMax) ? rgbA : rgbB;
}

void writeColor(Framebuffer& fb, int p, const Vec3& c, float amount = 1.0f) {
    const int i = p * 3;
    for (int channel = 0; channel < 3; ++channel) {
        const double base = fb.color[i + channel];
        const double filtered = channel == 0 ? c.x : (channel == 1 ? c.y : c.z);
        fb.color[i + channel] = static_cast<uint8_t>(std::clamp(
            (1.0 - amount) * base + amount * filtered, 0.0, 255.0));
    }
}

void applyGlobalFXAA(Framebuffer& fb) {
    const std::vector<uint8_t> source = fb.color;
    for (int y = 0; y < fb.height; ++y)
        for (int x = 0; x < fb.width; ++x)
            writeColor(fb, y * fb.width + x, resolveFXAA(source, fb.width, fb.height, x, y));
}

void applyLocalAdaptiveFXAA(Framebuffer& fb) {
    const std::vector<uint8_t> source = fb.color;
    for (int y = 0; y < fb.height; ++y) for (int x = 0; x < fb.width; ++x) {
        const int p = y * fb.width + x;
        if (!fb.stencil[p]) continue;
        // Silhouettes receive a restrained resolve; sharp apertures and depth
        // kinks can use the complete directional FXAA result.
        const float feature = fb.stencil[p] / 255.0f;
        const float amount = 0.45f + 0.55f * feature;
        writeColor(fb, p, resolveFXAA(source, fb.width, fb.height, x, y), amount);
    }
}

enum class AAMode { Off, FXAA, Adaptive };

double applyPostAA(Framebuffer& fb, AAMode mode) {
    if (mode == AAMode::Off) return 0.0;
    const auto begin = std::chrono::steady_clock::now();
    if (mode == AAMode::FXAA) {
        applyGlobalFXAA(fb);
    } else {
        buildSharpFeatureStencil(fb);
        applyLocalAdaptiveFXAA(fb);
    }
    return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - begin).count();
}

// ---------- X11 interactive window ----------
#ifdef HAS_X11
class X11Window {
public:
    struct Input {
        bool quit = false;
        bool toggleBilateral = false;
        bool toggleRotate = false;
        int sigmaS = 0, sigmaR = 0, shin = 0; // -1 / 0 / +1
        int dragX = 0, dragY = 0;
        int zoom = 0; // wheel steps
    };

    X11Window(int w, int h, const char* title) : width(w), height(h), display(nullptr) {
        display = XOpenDisplay(nullptr);
        if (!display) return;

        int screen = DefaultScreen(display);
        Window root = RootWindow(display, screen);

        XSetWindowAttributes swa;
        swa.event_mask = ExposureMask | KeyPressMask | StructureNotifyMask |
                         ButtonPressMask | ButtonReleaseMask | ButtonMotionMask;
        window = XCreateWindow(display, root,
                               0, 0, static_cast<unsigned int>(w), static_cast<unsigned int>(h),
                               0, CopyFromParent, InputOutput, CopyFromParent,
                               CWEventMask, &swa);

        XStoreName(display, window, title);

        // Ask the window manager for a graceful close event
        wmDelete = XInternAtom(display, "WM_DELETE_WINDOW", False);
        XSetWMProtocols(display, window, &wmDelete, 1);

        XMapWindow(display, window);
        XFlush(display);

        gc = XCreateGC(display, window, 0, nullptr);
        imgBuf = new uint32_t[static_cast<size_t>(w) * h];

        ximage = XCreateImage(display, DefaultVisual(display, screen),
                              DefaultDepth(display, screen), ZPixmap, 0,
                              reinterpret_cast<char*>(imgBuf),
                              static_cast<unsigned int>(w), static_cast<unsigned int>(h), 32, 0);
    }

    ~X11Window() {
        if (display) {
            // Detach the buffer so XDestroyImage does not free our memory.
            if (ximage) {
                ximage->data = nullptr;
                XDestroyImage(ximage);
            }
            delete[] imgBuf;
            XFreeGC(display, gc);
            XDestroyWindow(display, window);
            XCloseDisplay(display);
        }
    }

    bool valid() const { return display != nullptr && ximage != nullptr; }

    Input poll() {
        Input in;
        if (!display) { in.quit = true; return in; }
        while (XPending(display) > 0) {
            XEvent e;
            XNextEvent(display, &e);
            switch (e.type) {
            case ClientMessage:
                if (static_cast<Atom>(e.xclient.data.l[0]) == wmDelete) in.quit = true;
                break;
            case DestroyNotify:
                in.quit = true;
                break;
            case KeyPress: {
                KeySym ks = XLookupKeysym(&e.xkey, 0);
                switch (ks) {
                case XK_q: case XK_Escape: in.quit = true; break;
                case XK_b: in.toggleBilateral = true; break;
                case XK_r: in.toggleRotate = true; break;
                case XK_1: in.sigmaS = -1; break;
                case XK_2: in.sigmaS = +1; break;
                case XK_3: in.sigmaR = -1; break;
                case XK_4: in.sigmaR = +1; break;
                case XK_5: in.shin = -1; break;
                case XK_6: in.shin = +1; break;
                default: break;
                }
                break;
            }
            case ButtonPress:
                if (e.xbutton.button == Button1) {
                    dragging = true;
                    lastX = e.xbutton.x;
                    lastY = e.xbutton.y;
                } else if (e.xbutton.button == Button4) {
                    in.zoom = +1;
                } else if (e.xbutton.button == Button5) {
                    in.zoom = -1;
                }
                break;
            case ButtonRelease:
                if (e.xbutton.button == Button1) dragging = false;
                break;
            case MotionNotify:
                if (dragging) {
                    in.dragX += e.xmotion.x - lastX;
                    in.dragY += e.xmotion.y - lastY;
                    lastX = e.xmotion.x;
                    lastY = e.xmotion.y;
                }
                break;
            default:
                break;
            }
        }
        return in;
    }

    void present(const Framebuffer& fb) {
        if (!display || !ximage) return;

        // Convert RGB bytes to 0xFFRRGGBB (X11 TrueColor, little-endian server)
        for (int y = 0; y < height; ++y) {
            int row = y * width;
            for (int x = 0; x < width; ++x) {
                int idx = (row + x) * 3;
                uint32_t r = fb.color[idx + 0];
                uint32_t g = fb.color[idx + 1];
                uint32_t b = fb.color[idx + 2];
                imgBuf[row + x] = 0xFF000000u | (r << 16) | (g << 8) | b;
            }
        }

        XPutImage(display, window, gc, ximage, 0, 0, 0, 0,
                  static_cast<unsigned int>(width), static_cast<unsigned int>(height));
    }

    void drawHUD(const std::vector<std::string>& lines) {
        if (!display) return;
        for (int pass = 0; pass < 2; ++pass) {
            // pass 0: black shadow, pass 1: white text
            XSetForeground(display, gc, pass == 0 ? 0x000000UL : 0xffffffUL);
            int off = pass == 0 ? 1 : 0;
            for (size_t i = 0; i < lines.size(); ++i) {
                XDrawString(display, window, gc, 10 + off,
                            20 + static_cast<int>(i) * 18 + off,
                            lines[i].c_str(), static_cast<int>(lines[i].size()));
            }
        }
        XFlush(display);
    }

private:
    Display* display;
    Window window;
    GC gc;
    XImage* ximage = nullptr;
    uint32_t* imgBuf = nullptr;
    Atom wmDelete;
    int width, height;
    bool dragging = false;
    int lastX = 0, lastY = 0;
};
#endif

// ---------- Full render + timing ----------
void renderAndBenchmark(const std::vector<Patch>& patches, EvalMode mode, const std::string& imgName) {
    const int tess = 32;
    Camera cam(Vec3(5.0, 5.0, 4.0), Vec3(0.0, 0.0, 1.5), Vec3(0.0, 0.0, 1.0), 45.0, 1024, 768);
    Vec3 lightDir = normalize(Vec3(1.0, 1.0, 2.0));

    Framebuffer fb(1024, 768);

    double tessMs = 0.0;
    double rasterMs = 0.0;

    if (mode == EvalMode::Batch4D) {
        auto t0 = std::chrono::high_resolution_clock::now();
        renderBatch4DPoints(patches, tess, cam, fb, lightDir);
        auto t1 = std::chrono::high_resolution_clock::now();
        tessMs = std::chrono::duration<double, std::milli>(t1 - t0).count();
        // No separate rasterization step: points and tangents are drawn directly.
        rasterMs = 0.0;
    } else {
        auto t0 = std::chrono::high_resolution_clock::now();
        std::vector<Triangle> tris = tessellate(patches, tess, mode, cam);
        auto t1 = std::chrono::high_resolution_clock::now();
        rasterize(tris, fb, lightDir);
        auto t2 = std::chrono::high_resolution_clock::now();

        tessMs = std::chrono::duration<double, std::milli>(t1 - t0).count();
        rasterMs = std::chrono::duration<double, std::milli>(t2 - t1).count();
    }

    savePPM(imgName, fb);

    const char* label = (mode == EvalMode::Batch4D) ? "Batch4D" :
                        (mode == EvalMode::Horner) ? "Horner" : "Bernstein";
    std::cout << "[" << label << "]\n";
    std::cout << "  Tessellation   : " << tessMs << " ms\n";
    std::cout << "  Rasterization  : " << rasterMs << " ms\n";
    std::cout << "  Total render   : " << (tessMs + rasterMs) << " ms\n";
    std::cout << "  Image saved to : " << imgName << "\n\n";
}

// ---------- Interactive render settings ----------
struct RenderSettings {
    double sigmaS = 1.0;    // spatial sigma   (0.1 .. 3.0)
    double sigmaR = 0.1;    // range sigma     (0.01 .. 0.5)
    double shininess = 32.0; // Blinn-Phong    (8 .. 128)
    bool bilateral = true;
    bool autoRotate = true;
    AAMode aa = AAMode::Adaptive;
    int width = 1024;
    int height = 768;
    double stillTheta = 0.8;
    double stillPhi = 0.30;
    double stillRadius = 6.0;
};

// Render one frame of the bilateral + Blinn-Phong pipeline into a PPM file.
int renderStill(const std::vector<Patch>& patches, const RenderSettings& s,
                int tess, bool unify, const std::string& outPath) {
    Mesh mesh = buildCleanMesh(patches, tess, unify);
    smoothCurvatureSpikesEWMA(mesh);
    computeRawNormals(mesh);
    stitchSmoothPatchNormals(mesh);
    bilateralFilterNormals(mesh, s.sigmaS, s.sigmaR);

    const int W = s.width, H = s.height;
    Vec3 target(0.0, 0.0, 1.5);
    const double theta = s.stillTheta, phi = s.stillPhi, radius = s.stillRadius;
    Vec3 eye = target + Vec3(radius * std::cos(phi) * std::cos(theta),
                             radius * std::cos(phi) * std::sin(theta),
                             radius * std::sin(phi));
    Camera cam(eye, target, Vec3(0, 0, 1), 45.0, W, H);

    std::vector<VSOut> vs;
    vertexStage(mesh, s.bilateral ? mesh.filteredNormal : mesh.rawNormal, cam, vs);

    ShadeParams sp;
    sp.eye = eye;
    sp.lightPos = Vec3(3.8, 3.8, 6.2);
    sp.baseR = 0.60f; sp.baseG = 0.66f; sp.baseB = 0.78f;
    sp.ambient = 0.12f; sp.specStrength = 1.0f;
    sp.shininess = static_cast<float>(s.shininess);
    sp.lightIntensity = 26.0f; sp.airExtinction = 0.025f;
    sp.baseRoughness = 0.20f; sp.curvatureRoughness = 0.20f;

    Framebuffer fb(W, H);
    fb.clear(14, 16, 22);
    rasterizeBlinnPhong(mesh, vs, fb, sp);
    const double aaMs = applyPostAA(fb, s.aa);
    savePPM(outPath, fb);

    std::cout << "Rendered " << outPath
              << " (bilateral=" << (s.bilateral ? "on" : "off")
              << ", sigmaS=" << s.sigmaS
              << ", sigmaR=" << s.sigmaR
              << ", shininess=" << s.shininess
              << ", unify=" << (unify ? "yes" : "no") << ")\n";
    std::cout << "Post AA: " << (s.aa == AAMode::Off ? "off" :
                                  (s.aa == AAMode::FXAA ? "global-fxaa" : "local-adaptive-fxaa"))
              << " (" << aaMs << " ms)\n";
    return 0;
}

#ifdef HAS_X11
int runInteractive(const std::vector<Patch>& patches, RenderSettings s,
                   int tess, bool unify) {
    Mesh mesh = buildCleanMesh(patches, tess, unify);
    smoothCurvatureSpikesEWMA(mesh);
    computeRawNormals(mesh);
    stitchSmoothPatchNormals(mesh);
    bilateralFilterNormals(mesh, s.sigmaS, s.sigmaR);
    std::cout << "Mesh: " << mesh.pos.size() << " vertices, "
              << mesh.tris.size() << " triangles (tess=" << tess
              << ", unify=" << (unify ? "yes" : "no")
              << ", clean Bezier surface + EWMA spike cleanup)\n";

    const int W = 1024, H = 768;
    X11Window win(W, H, "Utah Teapot - bilateral normal filter + Blinn-Phong (software)");
    if (!win.valid()) {
        std::cerr << "No X11 display; use --still <out.ppm> to render offline.\n";
        return 1;
    }

    std::cout << "Controls: drag = orbit, wheel = zoom\n"
                 "  [b] bilateral on/off   [1/2] spatialSigma -/+\n"
                 "  [3/4] rangeSigma -/+   [5/6] shininess -/+\n"
                 "  [r] auto-rotate        [q/Esc] quit\n";

    double theta = 0.8, phi = 0.30, radius = 6.0;
    const Vec3 target(0.0, 0.0, 1.5);

    Framebuffer fb(W, H);
    std::vector<VSOut> vs;

    bool filterDirty = false;
    double fps = 0.0;
    auto prevTime = std::chrono::steady_clock::now();

    while (true) {
        X11Window::Input in = win.poll();
        if (in.quit) break;

        if (in.toggleBilateral) s.bilateral = !s.bilateral;
        if (in.sigmaS != 0) {
            s.sigmaS = std::clamp(s.sigmaS * (in.sigmaS > 0 ? 1.15 : 1.0 / 1.15), 0.1, 3.0);
            filterDirty = true;
        }
        if (in.sigmaR != 0) {
            s.sigmaR = std::clamp(s.sigmaR * (in.sigmaR > 0 ? 1.15 : 1.0 / 1.15), 0.01, 0.5);
            filterDirty = true;
        }
        if (in.shin != 0)
            s.shininess = std::clamp(s.shininess * (in.shin > 0 ? 1.4142 : 1.0 / 1.4142), 8.0, 128.0);
        if (in.toggleRotate) s.autoRotate = !s.autoRotate;
        theta += in.dragX * 0.008;
        phi = std::clamp(phi + in.dragY * 0.008, -1.35, 1.35);
        if (in.zoom != 0)
            radius = std::clamp(radius * (in.zoom > 0 ? 0.93 : 1.0 / 0.93), 3.0, 15.0);

        auto now = std::chrono::steady_clock::now();
        double dt = std::chrono::duration<double>(now - prevTime).count();
        prevTime = now;
        if (dt > 0.0 && fps > 0.0) fps = 0.9 * fps + 0.1 / dt;
        else if (dt > 0.0) fps = 1.0 / dt;
        if (s.autoRotate) theta += dt * 0.4;

        if (filterDirty) {
            bilateralFilterNormals(mesh, s.sigmaS, s.sigmaR);
            filterDirty = false;
        }

        Vec3 eye = target + Vec3(radius * std::cos(phi) * std::cos(theta),
                                 radius * std::cos(phi) * std::sin(theta),
                                 radius * std::sin(phi));
        Camera cam(eye, target, Vec3(0, 0, 1), 45.0, W, H);

        vertexStage(mesh, s.bilateral ? mesh.filteredNormal : mesh.rawNormal, cam, vs);

        ShadeParams sp;
        sp.eye = eye;
        sp.lightPos = Vec3(3.8, 3.8, 6.2);
        sp.baseR = 0.60f; sp.baseG = 0.66f; sp.baseB = 0.78f;
        sp.ambient = 0.12f; sp.specStrength = 1.0f;
        sp.shininess = static_cast<float>(s.shininess);
        sp.lightIntensity = 26.0f; sp.airExtinction = 0.025f;
        sp.baseRoughness = 0.20f; sp.curvatureRoughness = 0.20f;

        fb.clear(14, 16, 22);
        rasterizeBlinnPhong(mesh, vs, fb, sp);
        applyPostAA(fb, s.aa);
        win.present(fb);

        char buf[160];
        std::vector<std::string> hud;
        std::snprintf(buf, sizeof(buf), "bilateral [b]: %s", s.bilateral ? "ON" : "OFF");
        hud.emplace_back(buf);
        std::snprintf(buf, sizeof(buf), "spatialSigma [1/2]: %.2f", s.sigmaS);
        hud.emplace_back(buf);
        std::snprintf(buf, sizeof(buf), "rangeSigma   [3/4]: %.3f", s.sigmaR);
        hud.emplace_back(buf);
        std::snprintf(buf, sizeof(buf), "shininess    [5/6]: %.1f", s.shininess);
        hud.emplace_back(buf);
        std::snprintf(buf, sizeof(buf), "rotate [r]: %s   fps: %.0f",
                      s.autoRotate ? "on" : "off", fps);
        hud.emplace_back(buf);
        win.drawHUD(hud);

        // ~60 FPS cap
        auto frameEnd = std::chrono::steady_clock::now();
        double frameMs = std::chrono::duration<double, std::milli>(frameEnd - now).count();
        if (frameMs < 16.0)
            std::this_thread::sleep_for(std::chrono::milliseconds(static_cast<int>(16.0 - frameMs)));
    }
    return 0;
}
#endif

int main(int argc, char** argv) {
    std::string dataPath = "teapot.bpt";
    std::string stillPath;
    bool bench = false;
    bool unify = false;
    RenderSettings settings;
    int tess = 12;

    for (int i = 1; i < argc; ++i) {
        std::string a = argv[i];
        if (a == "--bench") bench = true;
        else if (a == "--unify=yes") unify = true;
        else if (a == "--unify=no") unify = false;
        else if (a == "--no-bilateral") settings.bilateral = false;
        else if (a == "--aa=off") settings.aa = AAMode::Off;
        else if (a == "--aa=fxaa") settings.aa = AAMode::FXAA;
        else if (a == "--aa=adaptive") settings.aa = AAMode::Adaptive;
        else if (a == "--size" && i + 1 < argc) {
            const std::string size = argv[++i];
            const size_t x = size.find('x');
            if (x == std::string::npos) { std::cerr << "Expected --size WIDTHxHEIGHT\n"; return 1; }
            settings.width = std::stoi(size.substr(0, x));
            settings.height = std::stoi(size.substr(x + 1));
            if (settings.width < 16 || settings.height < 16) {
                std::cerr << "Minimum render size is 16x16\n"; return 1;
            }
        }
        else if (a == "--camera" && i + 3 < argc) {
            settings.stillTheta = std::stod(argv[++i]);
            settings.stillPhi = std::stod(argv[++i]);
            settings.stillRadius = std::stod(argv[++i]);
            if (settings.stillRadius <= 0.1) { std::cerr << "Camera radius must be positive\n"; return 1; }
        }
        else if (a == "--still" && i + 1 < argc) stillPath = argv[++i];
        else if (a == "--sigma-s" && i + 1 < argc) settings.sigmaS = std::stod(argv[++i]);
        else if (a == "--sigma-r" && i + 1 < argc) settings.sigmaR = std::stod(argv[++i]);
        else if (a == "--shininess" && i + 1 < argc) settings.shininess = std::stod(argv[++i]);
        else if (a == "--tess" && i + 1 < argc) tess = std::stoi(argv[++i]);
        else if (a.rfind("--", 0) != 0) dataPath = a;
        else { std::cerr << "Unknown option: " << a << "\n"; return 1; }
    }

    std::vector<Patch> patches = loadTeapot(dataPath);
    std::cout << "Loaded " << patches.size() << " Bezier patches\n";

    if (bench) {
        // Warm-up so the first measurement is not affected by cold caches
        patches[0].evalHorner(0.5, 0.5);
        patches[0].evalBernstein(0.5, 0.5);
        renderAndBenchmark(patches, EvalMode::Bernstein, "teapot_bernstein.ppm");
        renderAndBenchmark(patches, EvalMode::Horner, "teapot_horner.ppm");
        renderAndBenchmark(patches, EvalMode::Batch4D, "teapot_batch4d.ppm");
        return 0;
    }

    if (!stillPath.empty())
        return renderStill(patches, settings, tess, unify, stillPath);

#ifdef HAS_X11
    return runInteractive(patches, settings, tess, unify);
#else
    std::cerr << "Compiled without X11; use --still <out.ppm> or --bench.\n";
    return 1;
#endif
}
